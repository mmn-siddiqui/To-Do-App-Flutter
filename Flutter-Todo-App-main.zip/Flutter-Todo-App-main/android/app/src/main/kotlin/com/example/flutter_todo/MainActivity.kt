package com.example.flutter_todo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
